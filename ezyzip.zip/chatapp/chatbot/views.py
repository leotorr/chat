from django.shortcuts import render

from django.shortcuts import render
from django.http import HttpResponse

body = [
    {
        'title': 'Rent a Bot',
        'content': 'Feeling a little lonely on Valentines? *cough* loser *cough*. Well we have a solution for you! Rent our bot now to give you a sensations you;ve never experienced before!'
    }
]

def home(request):
    context = {
        'body': body
    }
    return render(request, 'base.html', context)

def index(request):
    return render(request, 'chatroom.html')